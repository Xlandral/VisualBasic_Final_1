﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CalculatedPrice = New System.Windows.Forms.Label()
        Me.PropertyTaxCalculator = New System.Windows.Forms.Label()
        Me.AssessedValue = New System.Windows.Forms.Label()
        Me.input = New System.Windows.Forms.TextBox()
        Me.BCalculate = New System.Windows.Forms.Button()
        Me.BExit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'CalculatedPrice
        '
        Me.CalculatedPrice.AutoSize = True
        Me.CalculatedPrice.Location = New System.Drawing.Point(246, 75)
        Me.CalculatedPrice.Name = "CalculatedPrice"
        Me.CalculatedPrice.Size = New System.Drawing.Size(92, 15)
        Me.CalculatedPrice.TabIndex = 3
        Me.CalculatedPrice.Text = "Calculated Price"
        '
        'PropertyTaxCalculator
        '
        Me.PropertyTaxCalculator.AutoSize = True
        Me.PropertyTaxCalculator.Location = New System.Drawing.Point(128, 22)
        Me.PropertyTaxCalculator.Name = "PropertyTaxCalculator"
        Me.PropertyTaxCalculator.Size = New System.Drawing.Size(129, 15)
        Me.PropertyTaxCalculator.TabIndex = 0
        Me.PropertyTaxCalculator.Text = "Property Tax Calculator"
        '
        'AssessedValue
        '
        Me.AssessedValue.AutoSize = True
        Me.AssessedValue.Location = New System.Drawing.Point(51, 75)
        Me.AssessedValue.Name = "AssessedValue"
        Me.AssessedValue.Size = New System.Drawing.Size(85, 15)
        Me.AssessedValue.TabIndex = 1
        Me.AssessedValue.Text = "&Assessed Value"
        '
        'input
        '
        Me.input.Location = New System.Drawing.Point(51, 93)
        Me.input.Name = "input"
        Me.input.Size = New System.Drawing.Size(100, 23)
        Me.input.TabIndex = 2
        '
        'BCalculate
        '
        Me.BCalculate.Location = New System.Drawing.Point(51, 135)
        Me.BCalculate.Name = "BCalculate"
        Me.BCalculate.Size = New System.Drawing.Size(75, 23)
        Me.BCalculate.TabIndex = 5
        Me.BCalculate.Text = "&Calculate"
        Me.BCalculate.UseVisualStyleBackColor = True
        '
        'BExit
        '
        Me.BExit.Location = New System.Drawing.Point(263, 135)
        Me.BExit.Name = "BExit"
        Me.BExit.Size = New System.Drawing.Size(75, 23)
        Me.BExit.TabIndex = 6
        Me.BExit.Text = "E&xit"
        Me.BExit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(166, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(0, 15)
        Me.Label1.TabIndex = 7
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label2.Location = New System.Drawing.Point(231, 93)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(107, 23)
        Me.Label2.TabIndex = 4
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(390, 208)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.BExit)
        Me.Controls.Add(Me.BCalculate)
        Me.Controls.Add(Me.input)
        Me.Controls.Add(Me.AssessedValue)
        Me.Controls.Add(Me.PropertyTaxCalculator)
        Me.Controls.Add(Me.CalculatedPrice)
        Me.Name = "Form1"
        Me.Text = "Property Tax Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents CalculatedPrice As Label
    Friend WithEvents PropertyTaxCalculator As Label
    Friend WithEvents AssessedValue As Label
    Friend WithEvents input As TextBox
    Friend WithEvents BCalculate As Button
    Friend WithEvents BExit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
End Class
