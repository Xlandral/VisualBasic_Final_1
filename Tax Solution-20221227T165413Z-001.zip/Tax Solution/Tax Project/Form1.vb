﻿Public Class Form1
    Private Sub BExit_Click(sender As Object, e As EventArgs) Handles BExit.Click
        Me.Close()
    End Sub

End Class
